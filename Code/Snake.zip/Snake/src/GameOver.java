import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class GameOver {
	private EntityId id;
	private int x, y;
	
	public GameOver(int x, int y, EntityId id)
	{
		this.x = x;
		this.y = y;
		this.id = id;
	}
	
	public void paintComponent(Graphics g) {
		g.setColor(Color.red);
		g.setFont(new Font("Serif", Font.BOLD, 50));
		g.drawString("Game Over", x, y);
	}
	
}