import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class Entity extends JPanel {

	private static final long serialVersionUID = 1L;
	int x, y, dx, dy, w, h;
	EntityId id;
	
	public Entity(int x, int y, int w, int h, EntityId id) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.id = id;
	}
	
	public void paintComponent(Graphics g) {
		g.setColor(Color.ORANGE);
		g.fillRect(x, y, w, h);
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public void setDx(int dx) {
		this.dx = dx;
	}
	
	public void setDy(int dy) {
		this.dy = dy;
	}
	
	public void setW(int w) {
		this.w = w;
	}
	
	public void setH(int h) {
		this.h = h;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public int getDx() {
		return dx;
	}
	
	public int getDy() {
		return dy;
	}
	
	public int getW() {
		return w;
	}
	
	public int getH() {
		return h;
	}
	
	public EntityId getId() {
		return id;
	}
	
	public void update() {
		x += dx;
		y += dy;
	}
}