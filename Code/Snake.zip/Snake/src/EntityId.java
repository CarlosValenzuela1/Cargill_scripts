public enum EntityId {
	Entity(),
	Player(),
	Food(),
	GameOver();
}