import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import javax.swing.JPanel;
import javax.swing.Timer;

public class Game extends JPanel implements KeyListener, ActionListener {

	//Not used methods
	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e) {}
	
	//Variable initialization
	private static final long serialVersionUID = 1L;									//Required for serialization warning
	private int x, y;																	//Useful for moving the snake body
	private int randomNumX, randomNumY;
	
	//Object initialization
	private Player head = new Player(Main.WINDOW_WIDTH/2, 700, 50, 50, EntityId.Player);
	private GameOver gameOver = new GameOver(Main.WINDOW_WIDTH/2 - 100, Main.WINDOW_HEIGHT/2, EntityId.GameOver);
	private Food food = new Food(Main.WINDOW_WIDTH/2, 200, 50, 50, EntityId.Food);
	
	//ArrayList that holds the head and body of Snake
	private ArrayList<Player> list = new ArrayList<Player>();
	private Player temp;																//Useful to store temp piece of body object of the snake
	private boolean dead = false;
	private String direction = "up";													//Direction of snake movement
	
	public Random rand = new Random();													//Random method for food after being eaten
	
	//Constructor
	public Game()
	{
		Timer timer = new Timer(50, this);
		timer.start();
		this.addKeyListener(this);
		setFocusable(true);													//To be able to use keyboard keys without having to click on window first
		list.add(head);
	}
	
	public void paintComponent(Graphics g) {
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT);
		
		if(dead == false) {		
			food.paintComponent(g);
			paintSnake(g);
		}
		else
			deadSnake(g);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
        update();
        repaint();
	}
	
	public void update() {
		updateSnake();
		collision();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_DOWN) 
			moveDown();
		if (e.getKeyCode() == KeyEvent.VK_UP) 
			moveUp();
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) 
			moveRight();
		if (e.getKeyCode() == KeyEvent.VK_LEFT) 
			moveLeft();	
	}
		
	public void moveDown() {
		if(!direction.equalsIgnoreCase("up")) {
			temp.moveDown();
			direction = "down";
		}
	}
	
	public void moveUp() {
		if(!direction.equalsIgnoreCase("down")) {
			temp.moveUp();
			direction = "up";
		}
	}
	
	public void moveRight() {
		if(!direction.equalsIgnoreCase("left")) {
			temp.moveRight();
			direction = "right";
		}
	}
	
	public void moveLeft() {
		if(!direction.equalsIgnoreCase("right")) {
			temp.moveLeft();
			direction = "left";
		}
	}
	
	public void paintSnake(Graphics g) {
		for(int i = 0; i < list.size(); i++) 
			list.get(i).paintComponent(g);
	}
	
	public void updateSnake() {
		if(temp == null)
			temp = list.get(0);
		temp.update();
		list.add(0, new Player(temp.getX(), temp.getY(), temp.getW(), temp.getH(), EntityId.Player));
		
		/* If ran like this, all squares are drawn at the same location 
		 * because what's being passed is the reference and not an actual Obj.
		 * Therefore changes affect all Objs because they are actually the same Obj
		 * with its reference copied to all indexes of the list, NOT the actual Obj.
		 * ------------------------- list.add(0, temp); ------------------------- */
		list.remove(list.size()-1);
	}
	
	public void collision() {
		Rectangle border = getBounds();
		Rectangle snake = new Rectangle(list.get(0).getX(), list.get(0).getY(), list.get(0).getW(), list.get(0).getH());
		Rectangle food = new Rectangle(this.food.getX(), this.food.getY(), this.food.getW(), this.food.getH());
		if(snake.intersects(border) == false)
			dead = true;
		if(snake.intersects(food)) {
			eat();
			createFood();
			growSnake();
		}
	}
	
	public void deadSnake(Graphics g) {
		gameOver.paintComponent(g);
	}
	
	public void createFood() {
		/* This random is better after Java 1.7, since there's no need to explicitly initialize java.util.Random instance
		 * High bound for X is 20, since random * 50 must be less than 1000 to remain inside of the screen
		 * High bound for Y is 17, since random * 50 must be less than 880 to remain inside of the screen 
		 * The number 50 is explicitly defined so food appears on multiples of 50 to match with coordinates of snake  */
		randomNumX = (ThreadLocalRandom.current().nextInt(0, 20) * 50);				
		randomNumY = (ThreadLocalRandom.current().nextInt(0, 17) * 50);		
		food = new Food(randomNumX, randomNumY, 50, 50, EntityId.Food);
	}
	
	public void eat() {
		food.setEaten(true);
	}
	
	public void growSnake() {
		list.add(new Player(food.getX(), food.getY(), food.getW(), food.getH(), EntityId.Player));
	}
}