import javax.swing.JFrame;

public class Main extends JFrame {

	private static final long serialVersionUID = 1L;
	
	//Sets the Width and Height of the Window of the game
    final static int WINDOW_WIDTH = 1000;
    final static int WINDOW_HEIGHT = 880;
    
	public Main()
	{
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setResizable(false);												//Doesn't allow the user to change the size of the Window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);						//When window is closed it stops executing java (Otherwise it continues after being closed)
        
        add(new Game());													//Creates a new Panel and adds it to the Window. Panel is the name of the class created by us
        setBounds(0, 0, Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT);				//Sets the bounds, which are used to bounce the ball on them
        setLocation(915, 195);
        
        //setLocationRelativeTo(null);										//It centers the Window upon creation
        setVisible(true);													//Makes the Window visible
	}
	public static void main(String[] args) {
		new Main();
	}

}