public class Player extends Entity {
	
	private static final long serialVersionUID = 1L;

	public Player(int x, int y, int w, int h, EntityId id) {
		super(x, y, w, h, id);
	}

	public void moveDown() {
		this.setDx(0);
		this.setDy(50);
	}
	
	public void moveUp() {
		this.setDx(0);
		this.setDy(-50);
	}
		
	public void moveRight() {
		this.setDx(50);
		this.setDy(0);
	}
	
	public void moveLeft() {
		this.setDx(-50);
		this.setDy(0);
	}
}