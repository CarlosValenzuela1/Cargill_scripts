import java.awt.Color;
import java.awt.Graphics;

public class Food extends Entity{

	private static final long serialVersionUID = 1L;
	private boolean eaten = false;

	public Food(int x, int y, int w, int h, EntityId id) {
		super(x, y, w, h, id);
	}

	@Override
	public void paintComponent(Graphics g) {
		g.setColor(Color.pink);
		g.fillRect(x, y, w, h);
	}
	
	public boolean getEaten() {
		return eaten;
	}
	
	public void setEaten(boolean eaten) {
		this.eaten = eaten;
	}
}