import java.awt.Color;
import java.awt.Graphics;
import java.security.acl.LastOwnerException;
import java.util.Random;

public class Block extends Entity
{
	private int x,  y, width, height;
	private int R, G, B, result1, result2, result3;
	private static final int LOWRANDOM = 0, HIGHRANDOM = 254; 
	Random random = new Random();
	
    public Block(int x, int y, int width, int height)
    {
    	super(x, y, width, height);
    	this.x = x;
    	this.y = y;
    	this.width = width;
    	this.height = height;
    }

    public void paint(Graphics g) 
    {
    	result1 = random.nextInt(HIGHRANDOM - LOWRANDOM) + LOWRANDOM;
    	result2 = random.nextInt(HIGHRANDOM - LOWRANDOM) + LOWRANDOM;
    	result3 = random.nextInt(HIGHRANDOM - LOWRANDOM) + LOWRANDOM;
    	Color color = new Color(result1, result2, result3);
        g.setColor(color);
        g.fillRect(getX(), getY(), width, height);
    }   
}
