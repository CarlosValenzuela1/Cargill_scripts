import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Ball extends Entity
{
	private int x,  y, width, height, dx = 0, dy = 0;
	private Random r = new Random();
	
    public Ball(int x, int y, int width, int height)
    {
    	super(x, y, width, height);
    	this.x = x;
    	this.y = y;
    	this.width = width;
    	this.height = height;
    }
    
    public void paint(Graphics g) 
    {
    	Color color = new Color(255, 255, 255);
        g.setColor(color);
        g.fillRect(getX(), getY(), width, height);
    }

    public void move()
    {
    	this.setDx(dx);
    	this.setDy(dy);
    	update();
    }
    
    public void move(int adx, int ady)
    {
    	this.setDx(adx);
    	dx = adx;
    	this.setDy(ady);
    	dy = ady;
    	update();
    }
    
    public int getDx()
    {
    	return dx;
    }
    public int getDy()
    {
    	return dy;
    }    
}
