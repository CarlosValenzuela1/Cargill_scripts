import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class Entity extends JPanel
{
	private int x, y, width, height;
	private int dx = 0, dy = 0;
	
	public Entity(int x, int y, int width, int height)
	{
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public void setY(int y)
	{
		this.y = y;
	}
	
	public int getX()
	{
		return x;
	}
	
	public int getY()
	{
		return y;
	}
	
	@Override
	public void paint(Graphics g) 
    {
    	Color color = new Color(238, 130, 238);
        g.setColor(color);
        g.fillRect(x, y, width, height);
    }
	
	public void update()
	{
		x += dx;
		y += dy;
	}
	
	public void setDx(int dx)
	{
		this.dx = dx;
	}
	
	public void setDy(int dy)
	{
		this.dy = dy;
	}
	
	public int getWidth()
	{
		return width;
	}
	
	public int getHeight()
	{
		return height;
	}
}
