import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.lang.reflect.Array;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.text.StyledEditorKit.ForegroundAction;

public class Panel extends JPanel implements ActionListener, KeyListener 
{
	//Unused method
	public void keyTyped(KeyEvent e) {}
	
    Player player = new Player((Main.WINDOW_WIDTH/2)-50, 900, 100, 10);
    Ball ball = new Ball(Main.WINDOW_WIDTH/2-100, Main.WINDOW_HEIGHT/2, 10, 10); 
    ArrayList<Block> list;
    
     
    //Default Constructor which creates a Timer and makes the Panel focusable, so the keys can be listened
    public Panel() 
    {
        Timer time = new Timer(50, this);
        time.start();
        
        this.addKeyListener(this);
        this.setFocusable(true);
        list = createBlocks();
    }

    private void update() 
    {
    	player.update();
        ball.update();      
        checkCollisionAutomatic();
    }

    public void paintComponent(Graphics g) 
    {
        g.setColor(Color.black);											//Sets background color
        g.fillRect(0, 0, Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT);			//Sets size and location within the Window

        player.paint(g);
        ball.paint(g);
        
        //Block temp = list.get(0);
        //temp.paint(g);
        paintBlocks(g);
    }

    //Everytime an action happens it re-calculates coordinates and it draws the player, etc again.
    public void actionPerformed(ActionEvent e) 
    {
        update();
        repaint();
    }

    public void keyPressed(KeyEvent e) 
    {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) 
           	player.moveRight();	
        else if (e.getKeyCode() == KeyEvent.VK_LEFT) 
        	player.moveLeft();
        else if (e.getKeyCode() == KeyEvent.VK_SPACE)
           	ball.move(10, 10); 
    }

    public void keyReleased(KeyEvent e) 
    {
    	if(e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_LEFT)
    		player.setDx(0);
    }
    
    public void checkCollisionAutomatic() 
    {
    	Rectangle border = getBounds();
        Rectangle ballDimension = new Rectangle(ball.getX(), ball.getY(), ball.getWidth(), ball.getHeight());
		Rectangle playerDimension = new Rectangle(player.getX(), player.getY(), player.getWidth(), player.getHeight());
		
		if ((int) border.getMaxX() < (int) ballDimension.getMaxX() || (int) border.getMinX() > (int) ballDimension.getMinX()) 
			ball.move(ball.getDx() * -1, ball.getDy());
					
		if((int) border.getMaxY() < (int) ballDimension.getMaxY())
			ball.move(ball.getDx(), ball.getDy() * -1);
		if((int) border.getMinY() > (int) ballDimension.getMinY())
			ball.move(ball.getDx(), ball.getDy() * -1);
		
		if(ballDimension.intersects(playerDimension))
			ball.move(ball.getDx(), ball.getDy() * -1); 
	}
    
    public ArrayList<Block> createBlocks()
    {
        
        ArrayList<Block> list = new ArrayList<Block>();
        for(int i = 0; i < 20; i++) 
        {
        	int[] blockXPos = {0, 50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950};
        	System.out.println("This is position now: " + blockXPos[i]);
        	list.add(new Block(blockXPos[i], 0, 49, 20));        	
        }
        return list;
    }
    
    public void paintBlocks(Graphics g)
    {
    	   for(int i = 0; i < 20; i++) 
           {
           		//list.add(new Block(i, 0, 50, 20));
    		   Block temp = list.get(i);
    		   temp.paint(g);
    		   System.out.println("Current value for i: "  + i);
    		   System.out.println("Current value for temp: "  + temp);
           }
    }
}
