import java.awt.Color;
import java.awt.Graphics;

public class Player extends Entity
{
	private int x,  y, width, height;
	
    public Player(int x, int y, int width, int height)
    {
    	super(x, y, width, height);
    	this.x = x;
    	this.y = y;
    	this.width = width;
    	this.height = height;
    }

    public void moveRight()
    {
    	if(this.getX() + width < Main.WINDOW_WIDTH)
    		this.setDx(15);
    	else
    		this.setDx(0);
    }
    
    public void moveLeft()
    {
    	if(this.getX() > 0)
    		this.setDx(-15);
    	else
    		this.setDx(0);
    }
    
    public void paint(Graphics g) 
    {
    	Color color = new Color(0, 0, 255);
        g.setColor(color);
        g.fillRect(getX(), getY(), width, height);
    }   
}
