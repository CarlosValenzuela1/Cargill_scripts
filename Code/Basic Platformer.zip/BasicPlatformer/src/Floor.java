import java.awt.Color;
import java.awt.Graphics;


public class Floor
{
    private int x = 25, y = 400;
    private int width = 40, height = 20;

    public Floor() 
    {
    	//N/A
    }
    public Floor(int givenX, int givenY, int givenWidth, int givenHeight)
    {
    	x = givenX;
    	y = givenY;
    	width = givenWidth;
    	height = givenHeight;
    }

    public void paint(Graphics g) 
    {
        g.setColor(Color.green);
        g.fillRect(x, y, width, height);
    }
    
    public int getX() 
    {
        return x;
    }

    public int getY() 
    {
        return y;
    }

    public int getWidth() 
    {
        return width;
    }

    public int getHeight() 
    {
        return height;
    }
    
//    public void setX(int position)
//    {
//    	x = position;
//    }
//    public void setY(int position)
//    {
//    	y = position;
//    }
//    public void setWidth(int givenWidth)
//    {
//    	width = givenWidth;
//    }
//    public void setHeight(int givenHeight)
//    {
//    	height = givenHeight;
//    }
}
