import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main extends JFrame 
{

	//Sets the Width and Height of the Window of the game
    final static int WINDOW_WIDTH = 800;
    final static int WINDOW_HEIGHT = 500;

    public Main() 
    {
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setResizable(false);												//Doesn't allow the user to change the size of the Window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);						//When window is closed it stops executing java (Otherwise it continues after being closed)
        
        add(new Panel());													//Creates a new Panel and adds it to the Window. Panel is the name of the class created by us
        setLocation(1110, 540);
        //setLocationRelativeTo(null);										//It centers the Window upon creation
        setVisible(true);													//Makes the Window visible
    }

    public static void main(String[] args) 
    {
        new Main();
    }
}
