import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Panel extends JPanel implements ActionListener, KeyListener 
{

    Player player = new Player();
    Floor floor = new Floor();
    Floor floor2 = new Floor(150, 400, 80, 40);
    BufferedImage picture;

    //Default Constructor which creates a Timer and makes the Panel focusable, so the keys can be listened
    public Panel() 
    {
        Timer time = new Timer(50, this);
        time.start();

        this.addKeyListener(this);
        this.setFocusable(true);
    }

    private void update() 
    {
    	
        player.update();
        setBoundaries();
        collition();
    }

    public void paintComponent(Graphics g) 
    {
        g.setColor(Color.black);											//Sets background color
        g.fillRect(0, 0, Main.WINDOW_WIDTH, Main.WINDOW_HEIGHT);			//Sets size and location within the Window

        player.paint(g);													//It calls the paintComponent method in Player class
        floor.paint(g);
        floor2.paint(g);
    }

    //Everytime an action happens it re-calculates coordinates and it draws the player, etc again.
    public void actionPerformed(ActionEvent e) 
    {
        update();
        repaint();
    }

    public void keyPressed(KeyEvent e) 
    {
        if (e.getKeyCode() == KeyEvent.VK_UP) 
        {
            player.setDy(-5);
        } 
        else if (e.getKeyCode() == KeyEvent.VK_DOWN) 
        {
            player.setDy(5);
            
        }
        else if (e.getKeyCode() == KeyEvent.VK_RIGHT) 
        {
        	player.setDx(5);
            //player.setDx(5);
            if (player.getX() + player.getWidth() > Main.WINDOW_WIDTH) 			//If player moves RIGHT longer than the border, it's movement get's stopped. Invisible boundary.
            {
                player.setDx(0);
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_LEFT) 
        {
            player.setDx(-5);
            if (player.getX() + player.getWidth() > Main.WINDOW_WIDTH - 28)		//If player moves LEFT longer than the border, it's movement get's stopped. Invisible boundary. 
            {
                player.setDx(0);
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_SPACE)
        {
        	player.setDy(-10);
        	player.setCollision(false);
        }
    }

    public void keyReleased(KeyEvent e) 
    {
    	if(e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_LEFT)
    		player.setDx(0);
    
    }

    public void keyTyped(KeyEvent e) 
    {
    }
    
    public void collition()
    {
    	Rectangle p = new Rectangle(player.getX(), player.getY(), player.getWidth(), player.getHeight());
    	Rectangle f = new Rectangle(floor.getX(), floor.getY(), floor.getWidth(), floor.getHeight());
    	Rectangle f2 = new Rectangle(floor2.getX(), floor2.getY(), floor2.getWidth(), floor2.getHeight());
    	if(p.intersects(f) || p.intersects(f2))
    	{
    		player.onCollision();
    	}
    }
    public void setBoundaries()
    {
    	if(player.getY() < 30)
    	{
    		player.setDy(0);
    		player.setY(player.getHeight());
    	}
    	if (player.getY() + 40 > Main.WINDOW_HEIGHT - 28) 					//If player moves DOWN longer than the border, it's movement get's stopped. Invisible boundary. 
        {
            player.setDy(0);
            player.setY(Main.WINDOW_HEIGHT - player.getHeight() - 10);
        }
    }
	public void getPicture() {
	    try {
            //picture = ImageIO.read(new File("C:/Users/c760912/Desktop/ball.jpeg"));
	    	picture = ImageIO.read(getClass().getClassLoader().getResource("test.png"));
	    	//picture = ImageIO.read(getClass().getClassLoader().getResource("Picture1.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
	    //pictureScaled = picture.getScaledInstance(40, 40, 4);
	}
}
