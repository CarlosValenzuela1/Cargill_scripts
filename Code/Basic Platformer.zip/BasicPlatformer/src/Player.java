import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Window;


public class Player 
{
    private int y = 300, x = 30;
    private int dy = 0, dx = 0;
    private int width = 20, height = 40;
    private int GRAVITY = 1;
    private boolean collision = false;

    public Player(){}							//Empty constructor

    public void update() 
    {
//        //IF falling out of screen adjust
//        if(y + height >= Main.WINDOW_HEIGHT)	//right value should be 28
//    	{
//    		setDy(0);
//    		y = Main.WINDOW_HEIGHT - this.height - 28;
//    	}
    
        doGravity();

        y = y + dy;
        x = x + dx;
                
    }

    public void paint(Graphics g) 
    {
    	Color playerColor = new Color(238, 130, 238);
        g.setColor(playerColor);
        g.fillRect(x, y, width, height);
    }

    public void setDy(int speed) 
    {
        dy = speed;
    }
    
    public void setDx(int speed) 
    {
        dx = speed;
    }
    
    public void setY(int position) 
    {
        y = position;
    }
    
    public void setX(int position)
    {
    	x = position;
    }
    
    
    public void setCollision(boolean givenCollision)
    {
    	collision = givenCollision;
    }

    public int getX() 
    {
        return x;
    }

    public int getY() 
    {
        return y;
    }

    public int getWidth() 
    {
        return width;
    }

    public int getHeight() 
    {
        return height;
    }   
    public void onCollision()
    {
    	this.setDy(0 - GRAVITY);
    	collision = true;
    	y += 1; 
    }
    
    public void doGravity()
    {
    		//This gives the feeling of gravity
        	y += dy;
        	dy += GRAVITY;
    	
    	
    }

}
