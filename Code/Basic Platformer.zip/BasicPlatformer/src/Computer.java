import java.awt.Color;
import java.awt.Graphics;

public class Computer 
{

    private Panel field;
    private int y = Main.WINDOW_HEIGHT / 2;
    private int yVelocity = 0;
    private int width = 10;
    private int height = 40;

    public Computer(Panel game) 
    {
        this.field = game;
    }

    public void update() 
    {
      /*  if (field.getBall().getY() < this.y) {
            //ball is above the computer
            yVelocity = -3;
        } else if (field.getBall().getY() > this.y) {
            yVelocity = 3;
        }
        y = y + yVelocity;
*/
    }

    public void paint(Graphics g) 
    {
        g.setColor(Color.red);
        g.fillRect(Main.WINDOW_WIDTH - (35 + width), y, width, height);
    }

    public int getX() 
    {
        return Main.WINDOW_WIDTH - 6 - (35 + width);
    }

    public int getY() 
    {
        return y;
    }

    public int getWidth() 
    {
        return width;
    }

    public int getHeight() 
    {
        return height;
    }
}
