package com.zittler.window;

import java.awt.Dimension;

import javax.swing.JFrame;

public class WindowProperties {
	
	public final static int WIDTH = 800, HEIGHT = 600;

	public WindowProperties(String title, Game game) {
		configureWindow(game);
		configureFrame(game, title);
		game.start();
	}

	private void configureWindow(Game game) {
		game.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		game.setMaximumSize(new Dimension(WIDTH, HEIGHT));
		game.setMinimumSize(new Dimension(WIDTH, HEIGHT));
	}

	private void configureFrame(Game game, String title) {
		JFrame frame = new JFrame(title);
		frame.add(game);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLocation(1100, 400);
		frame.setVisible(true);
	}
}