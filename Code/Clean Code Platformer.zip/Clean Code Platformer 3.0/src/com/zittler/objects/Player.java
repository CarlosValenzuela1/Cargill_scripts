package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import java.util.PrimitiveIterator.OfDouble;

import org.omg.CORBA.portable.ValueBase;

import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.window.Game;
import com.zittler.window.Handler;

public class Player extends Entity {

	private Handler handler;
	private float GRAVITY = .5f;
	private int w = 30, h = 60, MAX_SPEED = 300;
	private EntityId block = EntityId.Block;
	private EntityId stairs = EntityId.Stairs;
	private int numberOfStairs = 0;
	private int playerIsNotInThisStairs = 0;
	private boolean dead = false;

	public Player(int x, int y, Handler handler, EntityId id) {
		super(x, y, id);
		this.handler = handler;
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		x += dx;
		y += dy;

		if(isOnFloor() == false && isOnStairs() == false) {
			GRAVITY = .5f;
			dy += GRAVITY;
			if(dy > MAX_SPEED)
				dy = MAX_SPEED;
		}
		collision();
	}

	@Override
	public void render(Graphics g) {
		Color color = new Color(20, 20, 20);
		g.setColor(color);
		g.fillRect((int) x, (int) y, (int) w, (int) h);
	}

	private void collision() {
		for(Entity entity : handler.objects) {
			if(entity.getId() == block)
				blockCollision(entity);

			else if(entity.getId() == stairs) {
				stairsCollision(entity);
				
				numberOfStairs += 1;
				if((((Stairs)entity).isPlayerIsHere()) == false)
					playerIsNotInThisStairs += 1;
			}
		}
		if(numberOfStairs == playerIsNotInThisStairs) {
			setOnStairs(false);
		}
		else {
			setOnStairs(true);
			setOnFloor(false);
			setJumping(false);
		}
		numberOfStairs = 0;
		playerIsNotInThisStairs = 0;
	}

	public void jump() {
		if(isJumping() == false)
			setJumping(true);
		setDy(-10);
		setOnFloor(false);
	}

	public void moveRight() {
		setDx(5);
	}

	public void moveLeft() {
		setDx(-5);
	}

	public void moveUp() {
		setDy(-3);
	}

	public void moveDown() {
		setDy(3);
	}

	public void stopMovement() {
		setDx(0);
	}

	private void blockCollision(Entity block) {
		if(getBoundsRight().intersects(block.getBounds()))
			x = block.getX() - w;

		if(getBoundsLeft().intersects(block.getBounds()))
			x = block.getX() + 20;			

		if(getBoundsBottom().intersects(block.getBounds())) {
			y = block.getY() - h;
			setOnFloor(true);
			setOnStairs(false);
			setDy(0);
			setJumping(false);
		} else
			setOnFloor(false);

		if(getBoundsTop().intersects(block.getBounds())) {
			y = block.getY() + 20;
			dy = 0;
		}
	}
	
	private void stairsCollision(Entity stairs) {
		if(getBounds().intersects(stairs.getBounds()))
			((Stairs)stairs).setPlayerIsHere(true);
		else
			((Stairs)stairs).setPlayerIsHere(false);
	}

	public Rectangle getBounds() {
		return new Rectangle((int) x + 5, (int) y + 5, (int) w - 10, (int) h - 10);
	}

	public Rectangle getBoundsBottom() {
		return new Rectangle((int) ((int) x + (w/2) - (w/4)), (int) ((int) y + (h/2)), (int) w/2, (int) h/2);
	}

	public Rectangle getBoundsTop() {
		return new Rectangle((int) ((int) x + (w/2) - (w/4)), (int) y, (int) w/2, (int) h/2);
	}

	public Rectangle getBoundsRight() {
		return new Rectangle((int) ((int) x + w - 5), (int) y + 5, (int) 5, (int) h - 20);
	}

	public Rectangle getBoundsLeft() {
		return new Rectangle((int) x, (int) y + 5, (int) 5, (int) h - 20);
	}

	public boolean isDead() {
		return dead;
	}

	public void setDead(boolean dead) {
		this.dead = dead;
	}
}

