package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;

public class Block extends Entity {
	
	public Block(float x, float y, EntityId id) {
		super(x, y, id);
		this.id = id;
	}

	@Override
	public void update(LinkedList<Entity> object) {
		
	}

	@Override
	public void render(Graphics g) {
		Color color = new Color(25, 25, 25);
		g.setColor(color);
		g.fillRect((int) x, (int) y, 20, 20);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 20, 20);
	}

}
