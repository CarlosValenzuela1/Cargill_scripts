package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.window.Handler;

public class Treasure extends Entity {

	private Handler handler;
	private int w = 30, h = 20;
	private static final EntityId PLAYER = EntityId.Player;
	
	public Treasure(float x, float y, Handler handler, EntityId id) {
		super(x, y, id);
		this.handler = handler;
	}

	@Override
	public void update(LinkedList<Entity> objects) {
	}

	@Override
	public void render(Graphics g) {
		Color color = new Color(184, 61, 186);
		g.setColor(color);
		g.fillRect((int) x, (int) y, w, h);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, w, h);
	}

}
