package com.zittler.window;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;

import com.zittler.framework.Camera;
import com.zittler.framework.EntityId;
import com.zittler.framework.KeyInput;
import com.zittler.objects.GameOver;

public class Game extends Canvas implements Runnable {

	//Main
	public static void main(String[] args) {
		new WindowProperties("Test", new Game());
	}

	//Declaring Variables
	private static final long serialVersionUID = 1L;		//[Optional] Required for serialization
	public static int lanceCount = 0;
	private boolean running = false;
	public static boolean dead = false;
	private BufferedImage level = null;

	//Declaring Objects
	Thread thread = new Thread();
	Handler handler = new Handler();
	Camera camera = new Camera(0,0);
	GameOver gameOver;
	BufferedImageLoader loader = new BufferedImageLoader();

	private void init() throws IOException {
		gameOver = new GameOver(WindowProperties.WIDTH/2 - 100, WindowProperties.HEIGHT/2, EntityId.GameOver);
		loader = new BufferedImageLoader();
		level = loader.loadImage("/level2.png");
		loader.loadImageLevel(this, level);
		this.addKeyListener(new KeyInput(handler));
	}

	private void update() {
		handler.update();

		for(int i = 0; i< handler.objects.size(); i++)
			if(handler.objects.get(i).getId() == EntityId.Player)
				camera.update(handler.objects.get(i));
	}

	public synchronized void start() {
		if(running)
			return;

		running = true;
		thread = new Thread(this);
		thread.start();
	}


	@Override
	public void run() {
		try {
			init();
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.requestFocus();
		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0;					//frames per second
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		long timer = System.currentTimeMillis();
		while(running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			while(delta >= 1) {
				update();
				delta--;
			}
			render();
			if(System.currentTimeMillis() - timer > 1000) 
				timer += 1000;
		}
	}

	private void render() {
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		Graphics g = bs.getDrawGraphics();
		Graphics2D g2d = (Graphics2D) g; 
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, getWidth(), getHeight());

		/********************
		 * Camera beginning *
		 *******************/
		if(dead != true) {
			g2d.translate(camera.getX(), camera.getY());
			handler.render(g);
			g2d.translate(camera.getX(), camera.getY());
		}
		else{
			System.out.println("Before dead");
			gameOver.render(g);
			System.out.println("After dead");
		}
		/********************
		 * Camera beginning *
		 *******************/	

		g.dispose();
		bs.show();
	}

}
