package com.zittler.framework;

//ID of all possible objects on game
public enum EntityId {
	Entity(),
	Player(),
	Stairs(),
	Block(),
	Ghoul(),
	SensitivePlatform(),
	Treasure(),
	Spike(),
	Lance(),
	Level(),
	Hadouken(),
	Bullet(),
	Portal(),
	GhostText(),
	Bee();
}
