package com.zittler.framework;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

public abstract class Entity {
	
	//Entity Facing Right = 1 | Entity Facing Left = -1
	protected int facing = 1;
	protected float x, y, dx = 0, dy = 0;
	protected boolean jumping = false, onStairs = false, onFloor = true, dead = false;
	protected EntityId id;
		
	public Entity(float x, float y, EntityId id) {
		this.x = x;
		this.y = y;
		this.id = id;
	}
	
	//Abstract methods
	//Forces child classes to use the Update/Render/getBounds methods
	public abstract void update(LinkedList<Entity> objects);
	public abstract void render(Graphics g);
	public abstract Rectangle getBounds();
	
	//Getters and Setters
	//X Position
	public float getX() {
		return x;
	}
	
	public void setX(float x) {
		this.x = x;
	}
	
	//Y Position
	public float getY() {
		return y;
	}
	
	public void setY(float y) {
		this.y = y;
	}
	
	//X Velocity
	public float getDx() {
		return dx;
	}
	
	public void setDx(float dx) {
		this.dx = dx;
	}
	
	//Y Velocity
	public float getDy() {
		return dy;
	}

	public void setDy(float dy) {
		this.dy = dy;
	}
	
	//Enum description
	public EntityId getId() {
		return id;
	}
	
	//State of entities setters and getters
	public void setJumping(boolean jumping){
		this.jumping = jumping;
	}
	
	public boolean isJumping() {
		return jumping;
	}
	
	public void setFacing(int facing) {
		this.facing = facing;
	}
	
	public int getFacing() {
		return facing;
	}
	
	public void setOnStairs(boolean onStairs) {
		this.onStairs =  onStairs;
	}
	
	public boolean isOnStairs() {
		return onStairs;
	}
	
	public boolean isOnFloor() {
		return onFloor;
	}

	public void setOnFloor(boolean onFloor) {
		this.onFloor = onFloor;
	}

	public boolean isDead() {
		return dead;
	}

	public void setDead(boolean dead) {
		this.dead = dead;
	}
}
