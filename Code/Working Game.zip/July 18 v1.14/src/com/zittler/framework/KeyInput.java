package com.zittler.framework;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.LinkedList;

import com.zittler.objects.Hadouken;
import com.zittler.objects.Lance;
import com.zittler.objects.Level;
import com.zittler.objects.Player;
import com.zittler.window.Game;
import com.zittler.window.GameOver;
import com.zittler.window.Handler;

public class KeyInput extends KeyAdapter {

	private Handler handler = new Handler();
	private boolean rightPressed = false, leftPressed = false, jumpPressed = false;
	private Entity entity;
	private int key;
	public static int weapon = 0;
	//private LinkedList<Level> levels = Game.levels;
	public static LinkedList<Level> levelsMenu = new LinkedList<Level>();
	public boolean hasSelectedLevel = false;

	public KeyInput(Handler handler) {
		this.handler = handler;
		levelsMenu.add(new Level("Tutorial Level", "/Levels/intro.png", GameOver.getGameOverX(), GameOver.getGameOverY(), false, true));
		levelsMenu.add(new Level("LEVEL I", "/Levels/level1.png", GameOver.getGameOverX(), GameOver.getGameOverY() + 50, true, true));
		levelsMenu.add(new Level("LEVEL II", "/Levels/level3.png", GameOver.getGameOverX(), GameOver.getGameOverY() + 100, false, true));
//		levelsMenu.add(new Level("Frederik's Level", "/Levels/level4.png", GameOver.getGameOverX(), GameOver.getGameOverY() + 150, false, true));
	}

	public void keyPressed(KeyEvent e) {
		key = e.getKeyCode();

		for(int i = 0; i < handler.objects.size(); i++) {
			entity = handler.objects.get(i);
			if(entity.getId() == EntityId.Player) {
				
				//Switch weapon
				if(key == KeyEvent.VK_0){
					switchWeapon();
				}
				
				//Print number of objects
				if(key == KeyEvent.VK_1){
					System.out.println("The number of objects is: " + handler.objects.size());
					System.out.println();
				}
				
				if(key == KeyEvent.VK_RIGHT) {
					((Player) entity).moveRight();
					setRightPressed(true);
				}

				if(key == KeyEvent.VK_LEFT) {
					((Player) entity).moveLeft();
					setLeftPressed(true);
				}

				//Disables infinite jumps or jumping while on stairs
				if(key == KeyEvent.VK_D && entity.isJumping() == false && entity.isOnStairs() == false) {
					((Player) entity).jump();
					setJumpPressed(true);
//					System.out.println(handler.toString());
				}
				
				//Can only go up while on stairs
				if(key == KeyEvent.VK_UP && entity.isOnStairs() == true)
					((Player)entity).moveUp();
				
				//Can only go down while on stairs
				if(key == KeyEvent.VK_DOWN && entity.isOnStairs() == true)
					((Player)entity).moveDown();
				
				//weapon 0 is a Lance
				//weapon 1 is a hadouken
				if(weapon == 0) {
					//Player can only shoot 3 lances at a time (Just like in the original game)
					if(key == KeyEvent.VK_F) {
//						if(key == KeyEvent.VK_F && Game.lanceCount < 3) {
						((Player)entity).setShooting(1);
						handler.addObject(new Lance(entity.getX(), entity.getY(), entity.getFacing(), handler, EntityId.Lance));
						Game.lanceCount++;
//						System.out.println(handler.toString());
					}
				} else if(weapon == 1) {
					if(key == KeyEvent.VK_F) {
						((Player)entity).setShooting(1);
						handler.addObject(new Hadouken(entity.getX(), entity.getY(), entity.getFacing(), handler, EntityId.Hadouken));						
					}
				}
			
			}
		}

		if(key == KeyEvent.VK_ESCAPE)
			System.exit(1);
		
		if(Game.levelHasBeenSelected == true && GameOver.isGameOver() == true && Game.menuIsShowing == false) {
			if(key == KeyEvent.VK_ENTER){
				Game.levelHasBeenSelected = false;
				GameOver.setGameOver(false);
				Game.menuIsShowing = true;
				Game.lanceCount = 0;
			}
		}
	}

	public void keyReleased(KeyEvent e) {
		key = e.getKeyCode();

		if(Game.menuIsShowing == false) {
			for(int i = 0; i < handler.objects.size(); i++) {
				entity = handler.objects.get(i);
				if(entity.getId() == EntityId.Player){
					if((key == KeyEvent.VK_RIGHT) && isLeftPressed() == true) {
						setRightPressed(false);
						((Player) entity).moveLeft();
					} 
					else if (key == KeyEvent.VK_RIGHT)
						setRightPressed(false);

					if((key == KeyEvent.VK_LEFT) && isRightPressed() == true) {
						setLeftPressed(false);
						((Player) entity).moveRight();
					} 
					else if (key == KeyEvent.VK_LEFT)
						setLeftPressed(false);
					
					//Stops movement of player when keys are released
					if((key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_LEFT) && entity.getDx() != 0 && isRightPressed() == false && isLeftPressed() == false) {
						((Player) entity).stopMovement();
					}
					
					if(key == KeyEvent.VK_UP && entity.isOnStairs())
						entity.setDy(0);
					
					if(key == KeyEvent.VK_DOWN && entity.isOnStairs())
						entity.setDy(0);
				}
			}
		} else if (Game.menuIsShowing == true) {
			if(key == KeyEvent.VK_UP) 
				menuPressedUp();
			
			if(key == KeyEvent.VK_DOWN)
				menuPressedDown();		
			
			if(key == KeyEvent.VK_ENTER) {
				loadSelectedLevel();
			}
				
		}

	}
	
	private void loadSelectedLevel() {
		for(int i=0; i < levelsMenu.size(); i++) {
			if(levelsMenu.get(i).isSelected() == true) {
				if(Game.test == 0) {
					Game.setLevelIndex(i);
					Game.test = 1;
				}
				Game.levelHasBeenSelected = true;
			}
		}
	}

	private void menuPressedUp() {		
		for(int i=0; i < levelsMenu.size(); i++) {
			if(levelsMenu.get(i).isSelected() == true) {
				if(levelsMenu.get(i).isVisible() == true) {
					if(i-1 >= 0) {
						levelsMenu.get(i).setSelected(false);
						levelsMenu.get(i-1).setSelected(true);	

					}
				}
			}
		}
		
	}
	
	private void menuPressedDown() {
		for(int i=0; i < levelsMenu.size(); i++) {
			if(levelsMenu.get(i).isSelected() == true) {
				if(i+1 < levelsMenu.size()) {
					levelsMenu.get(i).setSelected(false);
						levelsMenu.get(i+1).setSelected(true);					
					break;
				}
			}
		}
	}
	
	//Setters and getters
	public boolean isRightPressed() {
		return rightPressed;
	}

	public void setRightPressed(boolean rightPressed) {
		this.rightPressed = rightPressed;
	}

	public boolean isLeftPressed() {
		return leftPressed;
	}

	public void setLeftPressed(boolean leftPressed) {
		this.leftPressed = leftPressed;
	}

	public boolean isJumpPressed() {
		return jumpPressed;
	}

	public void setJumpPressed(boolean jumpPressed) {
		this.jumpPressed = jumpPressed;
	}
	
	//Method is static so Treasure class can activate SwitchWeapon when Treasure opens.
	public static void switchWeapon() {
		if(weapon == 1){
			weapon = 0;
		} else if(weapon == 0) {
			weapon = 1;
		}
	}
}
