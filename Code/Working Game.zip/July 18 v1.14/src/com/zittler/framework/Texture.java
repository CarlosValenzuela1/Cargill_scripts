package com.zittler.framework;

import java.awt.image.BufferedImage;
import com.zittler.window.BufferedImageLoader;

public class Texture {

	private SpriteSheet bs, ps, t, e, w, x, d;
	private BufferedImage blockSheet = null;
	private BufferedImage playerSheet = null;
	private BufferedImage treasureSheet = null;
	private BufferedImage enemiesSheet = null;
	private BufferedImage weaponsSheet = null;
	private BufferedImage explosionSheet = null;
	private BufferedImage doorSheet = null;
	
	public BufferedImage[] block = new BufferedImage[3];
	public BufferedImage[] player = new BufferedImage[22];
	public BufferedImage[] spike = new BufferedImage[2];
	public BufferedImage[] treasure = new BufferedImage[2];
	public BufferedImage[] stairs = new BufferedImage[1];
	public BufferedImage[] enemies = new BufferedImage[24];
	public BufferedImage[] weapons = new BufferedImage[2];
	public BufferedImage[] explosion = new BufferedImage[2];
	public BufferedImage[] door = new BufferedImage[1];
	
	public Texture() {
		BufferedImageLoader loader = new BufferedImageLoader();
		try {
			//Loading images from disk
			blockSheet = loader.loadImage("/Blocks/block_sheet_resized.png");
			playerSheet = loader.loadImage("/Player/player_sheet_transp.png");
			treasureSheet = loader.loadImage("/Objects/treasure_transp.png");
			enemiesSheet = loader.loadImage("/Enemies/enemies_transp.png");
			weaponsSheet = loader.loadImage("/Weapons/weapons_transp.png");
			explosionSheet = loader.loadImage("/Enemies/explosion_transp.png");
			doorSheet = loader.loadImage("/Objects/door.png");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		//Initialize the Sprite Sheets with their respective images
		bs = new SpriteSheet(blockSheet);
		ps = new SpriteSheet(playerSheet);
		t = new SpriteSheet(treasureSheet);
		e = new SpriteSheet (enemiesSheet);
		w = new SpriteSheet(weaponsSheet);
		x = new SpriteSheet(explosionSheet);
		d = new SpriteSheet(doorSheet);
		
		//Splits sprite images and adds them to array
		getTextures();
	}
	
	private void getTextures() {
		
		//Surface Floor
		block[0] = bs.grabImage(2, 1, 20, 20);
		
		//Mario Floor Original
		block[1] = bs.grabImage(1, 1, 20, 20);
		
		//Mario Floor Blue
		block[2] = bs.grabImage(4, 1, 20, 20);
		
		//Spikes
		spike[0] = bs.grabImage(3,  1, 20, 20);
		
		//Door
		door[0] = d.grabImage(1,  1, 40, 60);
		
		//Treasure
		treasure[0] = t.grabImage(1, 1, 40, 40);
		treasure[1] = t.grabImage(2, 1, 40, 40);
		
		//Stairs
		stairs[0] = bs.grabImage(6, 1, 20, 20);
		
		//Character (Player) is running RIGHT
		player[0] = ps.grabImage(1, 1, 32, 64);		
		player[1] = ps.grabImage(2, 1, 32, 64);
		player[2] = ps.grabImage(3, 1, 32, 64);
		player[3] = ps.grabImage(4, 1, 32, 64);
		player[4] = ps.grabImage(5, 1, 32, 64);
		player[5] = ps.grabImage(6, 1, 32, 64);
		player[6] = ps.grabImage(7, 1, 32, 64);
		
		//Character (Player) is running LEFT
		player[7] = ps.grabImage(1, 2, 32, 64);		
		player[8] = ps.grabImage(2, 2, 32, 64);
		player[9] = ps.grabImage(3, 2, 32, 64);
		player[10] = ps.grabImage(4, 2, 32, 64);
		player[11] = ps.grabImage(5, 2, 32, 64);
		player[12] = ps.grabImage(6, 2, 32, 64);
		player[13] = ps.grabImage(7, 2, 32, 64);
		
		//Character (Player) is Jumping Right
		player[14] = ps.grabImage(1, 3, 32, 64);
		player[15] = ps.grabImage(2, 3, 32, 64);
		
		//Character (Player) is Jumping Left
		player[16] = ps.grabImage(3, 3, 32, 64);
		player[17] = ps.grabImage(4, 3, 32, 64);
		
		//Character (Player) is Shooting RIGHT
		player[20] = ps.grabImage(1, 4, 40, 64);
		
		//Character (Player) is Shooting LEFT
		player[21] = ps.grabImage(2, 4, 40, 64);
		
		//Character (Player) On Stairs
		player[18] = ps.grabImage(5, 3, 32, 64);
		player[19] = ps.grabImage(6, 3, 32, 64);
		
		//Enemy ZOMBIE Idle 
		enemies[0] = e.grabImage(1, 1, 20, 40);
		enemies[1] = e.grabImage(2, 1, 20, 40);
		enemies[2] = e.grabImage(3, 1, 20, 40);
		enemies[3] = e.grabImage(4, 1, 20, 40);
		enemies[4] = e.grabImage(5, 1, 20, 40);
		enemies[5] = e.grabImage(6, 1, 20, 40);
		enemies[6] = e.grabImage(7, 1, 20, 40);
		enemies[7] = e.grabImage(8, 1, 20, 40);
		enemies[8] = e.grabImage(9, 1, 20, 40);
		enemies[9] = e.grabImage(9, 1, 20, 40);
		enemies[10] = e.grabImage(10, 1, 20, 40);
		enemies[11] = e.grabImage(11, 1, 20, 40);
		enemies[12] = e.grabImage(12, 1, 20, 40);
		enemies[13] = e.grabImage(13, 1, 20, 40);
		enemies[14] = e.grabImage(14, 1, 20, 40);
		enemies[15] = e.grabImage(15, 1, 20, 40);
		enemies[16] = e.grabImage(16, 1, 20, 40);
		
		//Enemy Zombie Walk LEFT
		enemies[17] = e.grabImage(1, 2, 20, 40);
		enemies[18] = e.grabImage(2, 2, 20, 40);
		enemies[19] = e.grabImage(3, 2, 20, 40);
		
		//Enemy Bee Flight Right
		enemies[20] = e.grabImage(1, 3, 20, 40);
		enemies[21] = e.grabImage(2, 3, 20, 40);
		
		//Enemy Bee Flight Left
		enemies[22] = e.grabImage(3, 3, 20, 40);
		enemies[23] = e.grabImage(4, 3, 20, 40);
		
		//Weapon Lance
		weapons[0] = w.grabImage(1, 1, 30, 10);
		weapons[1] = w.grabImage(2, 1, 30, 30);
		
		//Explosion of ENEMIES
		explosion[0] = x.grabImage(1, 1, 20, 20);
		explosion[1] = x.grabImage(2, 1, 20, 20);
	}
}
