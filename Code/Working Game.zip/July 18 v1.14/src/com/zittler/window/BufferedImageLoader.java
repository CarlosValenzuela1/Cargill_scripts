package com.zittler.window;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import com.zittler.framework.EntityId;
import com.zittler.objects.Bee;
import com.zittler.objects.Block;
import com.zittler.objects.GhostText;
import com.zittler.objects.Player;
import com.zittler.objects.Portal;
import com.zittler.objects.SensitivePlatform;
import com.zittler.objects.Spike;
import com.zittler.objects.Stairs;

public class BufferedImageLoader {
	
	//Ensures player is read once
	private static boolean wasPlayerRead = false;
	private BufferedImage image;
	
	public BufferedImageLoader() {
		wasPlayerRead = false;
	}
	
	//Reads level image
    public BufferedImage loadImage(String path) {
        try {
                image = ImageIO.read(getClass().getResource(path));
        } catch (IOException e) {
                e.printStackTrace();
        }
        return image;
    }

	//Traverses every pixel from image, if it matches a color, it instantiates an object.
	protected void loadImageLevel(Game game, BufferedImage image) {
		int w = image.getWidth(), h = image.getHeight();
		int pixel, red, green, blue;

		for(int i = 0; i < w - 1; i++) {
			for(int j = 0; j < h - 1; j++) {
				pixel = image.getRGB(i, j);
				red = (pixel >> 16) & 0xff;
				green = (pixel >> 8) & 0xff;
				blue = (pixel) & 0xff;

				if(red != 0 || green != 0 || blue != 0) {
					
					//Bright Red
					if(red == 237 && green == 28 && blue == 36) 
						game.handler.addObject(new Stairs(i * 20, j * 20, game.handler, EntityId.Stairs));

					//Dark Grey | Type 0 = Grass 
					if(red == 128 && green == 128 && blue == 128) 
						game.handler.addObject(new Block(i * 20, j * 20, 0, EntityId.Block));
					
					//Light Grey | Type 1 = Underground floor 
					if(red == 195 && green == 195 && blue == 195) 
						game.handler.addObject(new Block(i * 20, j * 20, 1, EntityId.Block));
					
					//Dark Red
//					if(red == 136 && green == 0 && blue == 21)
//						game.handler.addObject(new Ghoul(i * 20, j * 20, game.handler, EntityId.Ghoul));	

					//Light Brown
					if(red == 185 && green == 122 && blue == 86)
						game.handler.addObject(new SensitivePlatform(i * 20, j * 20, game.handler, EntityId.SensitivePlatform));
					
					//Orange
					if(red == 255 && green == 127 && blue == 39)
						game.handler.addObject(new Spike(i * 20, j * 20, game.handler, EntityId.Spike));
					
					//Yellow
					if(red == 255 && green == 242 && blue == 0)
						game.handler.addObject(new Bee(i * 20, j * 20, game.handler, EntityId.Bee));
					
					//Purple
					if(red == 163 && green == 73 && blue == 164)
						game.handler.addObject(new Portal(i * 20, j * 20, game.handler, EntityId.Portal));
					
					//Light Purple
					if(red == 200 && green == 191 && blue == 231)
						game.handler.addObject(new GhostText(i * 20, j * 20, EntityId.GhostText));
					
					//White
					if(wasPlayerRead == false) 
						if(red == 255 && green == 255 && blue == 255) {
							game.handler.addObject(new Player(i * 20, j * 20, game.handler, EntityId.Player));
							wasPlayerRead = true;
						}
				}
			}
		}
	}
}