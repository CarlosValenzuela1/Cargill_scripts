package com.zittler.window;

public class GameOver {

	private static int gameOverX = 370;
	private static int gameOverY = 250;
	private static boolean gameOver = false;

	public static int getGameOverX() {
		return gameOverX;
	}

	public static int getGameOverY() {
		return gameOverY;
	}
	
	public static void setGameOverX(int gameOverX) {
		GameOver.gameOverX = gameOverX;
	}

	public static void setGameOverY(int gameOverY) {
		GameOver.gameOverY = gameOverY;
	}
	
	public static boolean isGameOver() {
		return gameOver;
	}

	public static void setGameOver(boolean gameOver) {
		GameOver.gameOver = gameOver;
	}
}
