package com.zittler.window;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.LinkedList;
import com.zittler.window.GameOver;
import com.zittler.framework.Camera;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.KeyInput;
import com.zittler.framework.Texture;
import com.zittler.objects.Level;
import com.zittler.objects.Player;

public class Game extends Canvas implements Runnable {

	//The serializable class Game requires to have a serial version ID
	private static final long serialVersionUID = 1L;
	
	//Initializing objects
	Handler handler = new Handler();
	private BufferedImage level = null;
	private Thread thread = new Thread();
	private Camera camera = new Camera(0,0);
	private BufferedImageLoader loader = new BufferedImageLoader();
	static Texture texture;
	public static boolean menuIsShowing = true;
	public static boolean levelHasBeenSelected = false;
	public static LinkedList<Level> levels = new LinkedList<Level>();
	public static int test = 0;
	
	
	//Declaring variables
	private boolean running = false;
	public static int lanceCount = 0;
	public boolean gameOverOnce = false;
	public static String levelName = "/Levels/level0.png";
	public static int levelIndex;
	private boolean areLevelsLoaded = false;

	//MAIN
	public static void main(String[] args) {
		try{
		new WindowProperties("Game", new Game());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	//Initializes the Threads
	public synchronized void start() {
		if(running)
			return;

		running = true;
		thread = new Thread(this);
		thread.start();
	}
	
	//Initialize existing levels and adds them to the LinkedList
	private void loadLevels() {
		levels.add(new Level("Tutorial Level", "/Levels/intro.png", GameOver.getGameOverX(), GameOver.getGameOverY(), false, true));
		levels.add(new Level("LEVEL I", "/Levels/level1.png", GameOver.getGameOverX(), GameOver.getGameOverY() + 50, true, true));
		levels.add(new Level("LEVEL IA", "/Levels/level2.png", GameOver.getGameOverX(), GameOver.getGameOverY(), false, false));
		levels.add(new Level("LEVEL II", "/Levels/level3.png", GameOver.getGameOverX(), GameOver.getGameOverY() + 100, false, true));
	}
	
	//Initialize Level and Objects from image and adds Key Listener to Game
	private void init() throws IOException {
		texture = new Texture();
		loader = new BufferedImageLoader();
		level = loader.loadImage(levelName);
		loader.loadImageLevel(this, level);
		this.addKeyListener(new KeyInput(handler));	
	}

	//Updates physics on all objects (Calls update method in all objects)
	private void update() {
		handler.update();
		focusCameraOnPlayer();
		
		if(areLevelsLoaded == false) {
			loadLevels();
			areLevelsLoaded = true;
		}
	}	
	
	//Calls render method from Handler every 60 frames
	public void run() {
		try {
			init();
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.requestFocus();
		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0, delta = 0;
		double nanoSeconds = 1000000000 / amountOfTicks;
		long timer = System.currentTimeMillis();

		while(running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / nanoSeconds;
			lastTime = now;
			while(delta >= 1) {
				update();
				delta--;
			}
			try {
				render();
			} catch (IOException e) { e.printStackTrace(); 	}
			if(System.currentTimeMillis() - timer > 1000) 
				timer += 1000;
		}
	}

	//Calls Handler Render method and centers camera on player coordinates.
	private void render() throws IOException {
		System.out.println("Level Name: " + levelName);
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		Graphics g = bs.getDrawGraphics();
		Graphics2D g2d = (Graphics2D) g; 
		
		//Sets Background color for Graphics g
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, getWidth(), getHeight());
		g2d.translate(camera.getX(), camera.getY());
		
		
		//Shows Game Over screen if player is dead
		if(GameOver.isGameOver() == false) {
			if(menuIsShowing == true) {
				if(levelHasBeenSelected == false) {
					levelSelectionMenu(g);
				} else if (levelHasBeenSelected == true) {
					resetObjects();
				}
			}	
		}
		else if(GameOver.isGameOver() == true){ 
			handler = new Handler();
			g.setColor(new Color(255, 255, 255));
			g.drawString("END", GameOver.getGameOverX(), GameOver.getGameOverY());
			g.drawString("PRESS ENTER TO REPLAY THIS STAGE", GameOver.getGameOverX() - 100, GameOver.getGameOverY() + 300);
		}
		
		handler.render(g);
		

		//Changes the origin positions to be relative to player's coordinates
		g2d.translate(camera.getX(), camera.getY());
		g.dispose();
		bs.show();
	}

	//Focuses camera based on player coordinates and if player is dead initializes Game Over screen
	private void focusCameraOnPlayer() {
		for(Entity entity : handler.objects) {
			if(entity.getId() == EntityId.Player) {
				camera.update(entity);
				if(((Player) entity).isDead() == true) {
					GameOver.setGameOverX((int) entity.getX());
					GameOver.setGameOverY((int) entity.getY());
					GameOver.setGameOver(true);	
				}
			}
		}
	}
	
	private void levelSelectionMenu(Graphics g) {
		g.setColor(Color.PINK);
		for(Level level: KeyInput.levelsMenu) {
			if(level.isVisible() == true) {
				g.setColor(Color.CYAN);
				if(level.isSelected() == true) {
					g.setColor(Color.PINK);
					g.fillOval(level.getX() - 40, level.getY() - 25, 30, 30);
				}
				g.setFont(g.getFont().deriveFont((float) 30.0));
				g.drawString(level.getName(), level.getX(), level.getY());
			}
		}
	}

	public static Texture getInstance(){
		return texture;
	}
	
	public static String getLevelName() {
		return levelName;
	}

	private static void setLevelName(int i) {
		System.out.println("Index is bef" + i);
		Game.levelName = levels.get(i).getLocation();
		System.out.println("Index is aft" + i);
		System.out.println("Loading game: " + levels.get(i).getLocation());
	}

	public static int getLevelIndex() {	
		return levelIndex;
	}

	public static void setLevelIndex(int levelIndex) {
		if(levels.size() >= levelIndex) {
			setLevelName(levelIndex);
			Game.levelIndex = levelIndex;
		}
	}
	
	public void resetObjects() throws IOException {
		handler = new Handler();	
		init();
		menuIsShowing = false;
	}
}
