package com.zittler.window;

import java.awt.Graphics;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;

public class Handler {

	public LinkedList<Entity> objects = new LinkedList<Entity>();
	private Entity entity;
	private Entity playerEntity;
	private int indexOfPlayer = -1;

	//Calls update method in all existing objects
	public void update() {
		for(int i=0; objects.size() > i; i++) {
			Entity entity = objects.get(i);
			if(entity.getId() != EntityId.Treasure)
				entity.update(objects);
			if(entity.isDead() == true && entity.getId() != EntityId.Player)
				objects.remove(entity);
		}
	}

	//Calls render method in all existing objects, and puts player on top of the other sprites
	public void render(Graphics g) {
		for(int i=0; objects.size() > i; i++) {
			entity = objects.get(i);
			if(entity.getId() != EntityId.Player)
				entity.render(g);
			else if (entity.getId() == EntityId.Player)
				indexOfPlayer = i;
		}
		
		if(indexOfPlayer > 0) {
			playerEntity = objects.get(indexOfPlayer);
			playerEntity.render(g);
		}
	}

	//Adds Entity object to handler's array that holds all existing objects
	public void addObject(Entity object) {
		objects.add(object);
	}

	//Removes Entity object from handler's array that holds all existing objects
	public void removeObject(Entity object) {
		objects.remove(object);
	}
	
	//Adding method for easier visualization of contents for Debugging
	public String toString(){
		StringBuilder result = new StringBuilder();
	    for(Entity item : this.objects) {
	        result.append(item.toString());
	        result.append("\n"); //optional
	    }
	    return result.toString();
	}
}
