package com.zittler.window;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Animation {
	
		private int speed, frames, index = 0, count = 0;
		private BufferedImage[] images;
		private BufferedImage currentImage;

		//Takes speed and individual images from sprite to generate animation
		public Animation(int speed, BufferedImage... args) {
			this.speed = speed;
			images = new BufferedImage[args.length];
			for(int i = 0; i < args.length; i++)
				images[i] = args[i];
			frames = args.length;
		}
		
		//Runs each frame of animation based on specified speed
		public void runAnimation() {
			index++;
			if(index > speed) {
				index = 0;
				nextFrame();
			}
		}
		
		//Set's currentImage to the following image on the array and repeats animation if complete
		private void nextFrame() {
			for(int i = 0; i < frames; i++)
				if(count == i)
					currentImage = images[i];
			count++;
			if(count > frames)
				count = 0;
		}
		
		//Adds specific image to Graphics g, can also be called for individual images without the need of creating an Animation
		public void drawAnimation(Graphics g, int x, int y, int scaleX, int scaleY) {
			g.drawImage(currentImage, x, y, scaleX, scaleY, null);
		}
}
