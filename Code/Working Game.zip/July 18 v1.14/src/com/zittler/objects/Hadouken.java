package com.zittler.objects;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.Texture;
import com.zittler.window.Game;
import com.zittler.window.Handler;

public class Hadouken extends Entity{
	private int w = 30, h = 30;
	Texture texture = Game.getInstance();
	private int facing;
//	private Handler handler;
	private int distance;

	public Hadouken(float x, float y, int facing, Handler handler, EntityId id) {
		super(x, y, id);
		this.facing = facing;
//		this.handler = handler;
	}

	public void update(LinkedList<Entity> objects) {
		x += (10 * facing);
		distance++;
		checkDistance();
		if(isDead() == true){
			destroyHadouken();
		}
		
//		synchronized(this) {
//			checkDistance();
//		}
////		collision();
//		if(isDead() == true) {
//			synchronized(this) {
//				destroyHadouken();
//			}
//		}
			
	}
	
//	private void collision(){
//		for(Entity entity : handler.objects) {
//			if(entity.getId() == EntityId.Ghoul)
//				enemyCollision(entity);
//			else if(entity.getId() == EntityId.Bee)
//				enemyCollision(entity);
//		}
//	}
//	
//	private void enemyCollision(Entity enemy) {
//		if(getBounds().intersects(enemy.getBounds())) {
//			enemy.setDead(true);
//			this.setDead(true);
//		}
//	}
	
	public void checkDistance() {
		if(distance > 20) {
			destroyHadouken();
		}
	}
	
	public void destroyHadouken() {
		setDead(true);
//		handler.removeObject(this);
	}

	public void render(Graphics g) {
		g.drawImage(texture.weapons[1], (int) (x + 10), (int) (y + 30), null);
	}

	public Rectangle getBounds() {
		return new Rectangle((int) (x + 10), (int) (y + 30), w, h);
	}

}
