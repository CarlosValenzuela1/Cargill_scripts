package com.zittler.objects;


public class Level {
	String name;
	String location;
	int x, y;
	boolean selected;
	boolean visible;
	
	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	public Level(String name, String location, int x, int y, boolean selected, boolean visible) {
		this.name = name;
		this.location = location;
		this.x = x;
		this.y = y;
		this.selected = selected;	
		this.visible = visible;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
