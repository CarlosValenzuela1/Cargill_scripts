package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.Texture;
import com.zittler.window.Game;
import com.zittler.window.Handler;

public class Portal extends Entity {
	
	private Handler handler;
	private int w = 10, h = 10;
	private static final EntityId PLAYER = EntityId.Player;
	private int currentLevel;
	private boolean hasPortalBeenUsed = false;
	Texture texture = Game.getInstance();
	
	public Portal(float x, float y, Handler handler, EntityId id) {
		super(x, y, id);
		this.handler = handler;
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		collision(handler);
	}

	@Override
	public void render(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(getBounds().x, getBounds().y, getBounds().width, getBounds().height);
		
		g.drawImage(texture.door[0], (int) (x), (int) (y - 35), null);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x,(int) y, w, h);
	}
	
	public void collision(Handler handler) {
		for(Entity entity : handler.objects) {
			if(entity.getId() == PLAYER) {
				if(((Player) entity).getBoundsBottom().intersects(getBounds())) {
					if(hasPortalBeenUsed == false) {
						currentLevel = Game.getLevelIndex();
						currentLevel++;
						Game.setLevelIndex(currentLevel);
						Game.menuIsShowing = true;
						hasPortalBeenUsed = true;
					}
				}
			}
		}
	}
}
