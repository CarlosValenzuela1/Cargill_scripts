package com.zittler.objects;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.Texture;
import com.zittler.window.Game;
import com.zittler.window.Handler;

public class Lance extends Entity{
	private int w = 30, h = 10;
	Texture texture = Game.getInstance();
	private int facing;
//	private Handler handler;
	private int distance;

	public Lance(float x, float y, int facing, Handler handler, EntityId id) {
		super(x, y, id);
		this.facing = facing;
//		this.handler = handler;
	}

	public void update(LinkedList<Entity> objects) {
		x += (5 * facing);
		distance++;
		
		checkDistance();
		if(isDead() == true)
			destroyLance();
		
//		synchronized(this) {
//			checkDistance();	
//		}
//		collision();

	}
	
//	private void collision(){
//		for(Entity entity : handler.objects) {
//			if(entity.getId() == EntityId.Ghoul)
//				enemyCollision(entity);
//			else if(entity.getId() == EntityId.Bee)
//				enemyCollision(entity);
//		}
//	}
//	
//	private void enemyCollision(Entity enemy) {
//		if(getBounds().intersects(enemy.getBounds())) {
//			enemy.setDead(true);
//			this.setDead(true);
//		}
//	}
	
	public void checkDistance() {
		if(distance > 60) {
			destroyLance();
		}
	}
	
	public void destroyLance() {
		Game.lanceCount--;
		setDead(true);
//		handler.removeObject(this);
	}

	public void render(Graphics g) {
		g.drawImage(texture.weapons[0], (int) (x + 10), (int) (y + 30), null);
	}

	public Rectangle getBounds() {
		return new Rectangle((int) (x + 10), (int) (y + 30), w, h);
	}

}
