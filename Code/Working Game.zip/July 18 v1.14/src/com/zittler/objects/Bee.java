package com.zittler.objects;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.Texture;
import com.zittler.window.Animation;
import com.zittler.window.Game;
import com.zittler.window.Handler;

public class Bee extends Entity{

	private Handler handler;
	private int w = 20, h = 22, distanceX = 0, distanceY = 0, deadDuration = 0;
	private boolean playerIsAtLeft = false;
	private boolean playerIsAtRight = false;
	private boolean closeToPlayer = false;
	Texture texture = Game.getInstance();
	private Animation beeFlyingRight, beeFlyingLeft, explosion;
//	private Entity entity;
	
	public Bee(float x, float y, Handler handler, EntityId id) {
		super(x, y, id);
		this.handler = handler;	
		beeFlyingLeft = new Animation(10, texture.enemies[20], texture.enemies[21]);
		beeFlyingRight = new Animation(10, texture.enemies[22], texture.enemies[23]);
		explosion = new Animation(5, texture.explosion[0], texture.explosion[1]);
	}

	public void update(LinkedList<Entity> objects) {
		
		if(this.dead == false) {
			if(playerIsAtLeft == true) {
				moveBeeToLeft();
				beeFlyingLeft.runAnimation();
			} else if(playerIsAtRight == true) {
				moveBeeToRight();
				beeFlyingRight.runAnimation();
			}
			

			if(distanceY > 50) 
				distanceY = 0;

			synchronized(this) {
				collision(handler);
			}
			
			if(distanceX > 500) {
				setDead(true);
//				synchronized(this) {
//					handler.removeObject(this);	
//				}
			}
		}
	}



	private void moveBeeToLeft() {
		distanceX ++;
		distanceY ++;
		x -= 3;
		if(distanceY < 25) 
			goDown();
		else
			goUp();
	}
	
	private void moveBeeToRight() {
		distanceX ++;
		distanceY ++;
		x += 3;
		if(distanceY < 25) 
			goDown();
		else
			goUp();
	}
	
	private void goDown() {
		y += 1;
	}
	private void goUp() {
		y -= 1;
	}

	@Override
	public void render(Graphics g) {
//		Color color = new Color(255, 127, 39);
//		g.setColor(color);
//		g.fillRect(getBounds().x, getBounds().y, getBounds().width, getBounds().height);
		
//		if(this.dead == false && isCloseToPlayer() == false) {
//			g.drawImage(texture.enemies[20], (int) x, (int) y - 8, 20, 40, null);
//		}
			
		
		if(dead == false) {
			if(isCloseToPlayer() == true)
				if(playerIsAtLeft == true) {
					beeFlyingLeft.drawAnimation(g,(int) x, (int) y - 8, 20, 40);	
				} else if(playerIsAtRight == true) {
					beeFlyingRight.drawAnimation(g,(int) x, (int) y - 8, 20, 40);
				}
			else{
				g.drawImage(texture.enemies[20], (int) x, (int) y - 8, 20, 40, null);
			}
		}
				
		if(isDead() == true && deadDuration > 10) {
			setDead(true);
//			handler.removeObject(this);
		} else if(isDead() == true) {
			explosion.runAnimation();
			explosion.drawAnimation(g, (int) x, (int) y, 20, 20);
			deadDuration++;
		}
			
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y,  w, h);
	}

	public void collision(Handler handler) {
		
		if(this.dead == false) {
			for(Entity entity : handler.objects) {
				if(entity.getId() == EntityId.Player) {
					setCloseToPlayer(entity);
				}
				
				if(closeToPlayer == true) {
					if(entity.getId() == EntityId.Lance) {
						if(entity.getBounds().intersects(getBounds())) {
							entity.setDead(true);
							this.setDead(true);
						}
					}
					
					if(entity.getId() == EntityId.Hadouken) {
						if(entity.getBounds().intersects(getBounds())) {
							entity.setDead(true);
							this.setDead(true);
						}
					}
				}
			}
		}
	}
	
	public void setCloseToPlayer(Entity player) {
		if((x - player.getX()) <= 420 && (x - player.getX()) >= 0 && (y - player.getY() > -30) && (y - player.getY() < 30)) {
			playerIsAtLeft = true;
			closeToPlayer = true;
		}
		else 
			if((x - player.getX()) >= -420 && (x - player.getX()) <= -1 && (y - player.getY() > -30) && (y - player.getY() < 30)) {
			playerIsAtRight = true;
			closeToPlayer = true;
		}
			
		//Enemy continues moving after detecting Player
//		else
//			this.closeToPlayer = false;
	}

	public boolean isCloseToPlayer() {
		return closeToPlayer;
	}
}
