package com.zittler.objects;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;

public class GhostText extends Entity {
	
	public static String [] texts = {
			"Press LEFT or RIGHT arrows to run",
			"Press \"D\" to Jump",
			"Press UP or DOWN arrows to climb stairs",
			"Press \"F\" to Shoot",
			"Hidden treasures give you new weapons",
			"Stand here -->",
			"Great Job!"
	};
	
	public static int counter = 0;
	public int textIndex;
	
	public GhostText(float x, float y, EntityId id)
	{
		super(x, y, id);
		textIndex = counter;
		counter++;
	}
	
	@Override 
	public void render(Graphics g) {
		g.setColor(new Color(18, 232, 207));
		g.setFont(new Font("Serif", Font.PLAIN, 30));

		if(textIndex < texts.length) {
			g.drawString(texts[textIndex], (int) x, (int) y);
		} else {
			counter = 0;
			textIndex = 0;
		}
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		
	}

	@Override
	public Rectangle getBounds() {
		return null;
	}
	
}