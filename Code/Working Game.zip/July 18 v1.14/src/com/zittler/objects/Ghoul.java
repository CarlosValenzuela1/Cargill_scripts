package com.zittler.objects;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.Texture;
import com.zittler.window.Animation;
import com.zittler.window.Game;
import com.zittler.window.Handler;

public class Ghoul extends Entity{

//	private Handler handler;
	private int w = 20, h = 40;
	private int distance = 0;
	private boolean closeToPlayer = false;
	private static final EntityId PLAYER = EntityId.Player;
//	private static final EntityId GHOUL = EntityId.Ghoul;
	Texture texture = Game.getInstance();
	private Animation ghoulStand, ghoulWalk, explosion;
	private boolean ghoulDead = false;
	private int deadDuration = 0;
	
	public Ghoul(float x, float y, Handler handler, EntityId id) {
		super(x, y, id);
//		this.handler = handler;
		ghoulStand = new Animation(20, texture.enemies[0], texture.enemies[1], texture.enemies[2], texture.enemies[3], 
				texture.enemies[4], texture.enemies[5], texture.enemies[6], texture.enemies[7], texture.enemies[8],
				texture.enemies[9], texture.enemies[10], texture.enemies[11], texture.enemies[12], texture.enemies[13],
				texture.enemies[14], texture.enemies[15], texture.enemies[16]);
		
		ghoulWalk = new Animation(5, texture.enemies[17], texture.enemies[18], texture.enemies[19]);
		explosion = new Animation(5, texture.explosion[0], texture.explosion[1]);
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		if(isCloseToPlayer() == true) {
			distance ++;
			x -= 3;
		}
//		collision(handler);
		ghoulStand.runAnimation();
		ghoulWalk.runAnimation();
		if(distance > 200) {
			setDead(true);
			
//			handler.removeObject(this);
		}
	}

	@Override
	public void render(Graphics g) {
		if(dead == false) {
			if(isCloseToPlayer() == true)
				ghoulWalk.drawAnimation(g,(int) x, (int) y, 20, 40);
			else
				ghoulStand.drawAnimation(g,(int) x, (int) y, 20, 40);
		}
		
		if(isDead() == true && deadDuration > 10) {
			setDead(true);
			
//			handler.removeObject(this);
		} else if(isDead() == true) {
			explosion.runAnimation();
			explosion.drawAnimation(g, (int) x, (int) y, 20, 20);
			deadDuration++;
		}

	}

	public void collision(Handler handler) {
		for(Entity entity : handler.objects) {
			if(entity.getId() == PLAYER && ghoulDead == false) {
				setCloseToPlayer(entity);
			}
			
			if(entity.getId() == EntityId.Lance && this.dead == false) {
				if(entity.getBounds().intersects(getBounds())) {
					entity.setDead(true);
					this.setDead(true);
				}
			}
			
			if(entity.getId() == EntityId.Hadouken && this.dead == false) {
				if(entity.getBounds().intersects(getBounds())) {
					entity.setDead(true);
					this.setDead(true);
				}
			}
		}
	}
	
	
	public void setCloseToPlayer(Entity player) {
		if((x - player.getX()) <= 380 && (x - player.getX()) >= 0 && (y - player.getY() > -30) && (y - player.getY() < 30)) {
			//playerIsAtLeft = true;
			closeToPlayer = true;
		}
		else 
			if((x - player.getX()) >= -380 && (x - player.getX()) <= -1 && (y - player.getY() > -30) && (y - player.getY() < 30)) {
			//playerIsAtRight = true;
			closeToPlayer = true;
		}
			
		//Enemy continues moving after detecting Player
//		else
//			this.closeToPlayer = false;
	}
//	public void setCloseToPlayer(Entity player) {
//		if((x - player.getX()) <= 150 && (y - player.getY() <= 100))
//			this.closeToPlayer = true;
//		else
//			this.closeToPlayer = false;
//	}
	
	public boolean isCloseToPlayer() {
		return closeToPlayer;
	}
	
	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y,  w, h);
	}
}
